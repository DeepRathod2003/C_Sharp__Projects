﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ResultWindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String ins = "insert into student values('" + txtName.Text + "','" + txtAddress.Text + "','" + txtClass.Text + "','" + txtStream.Text + "','" + txtSem.Text + "','" + txtCity.Text + "')";
            SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.cn);
            int a = sda.Fill(Class1.dt);
            if (a <= 1)
            {
                MessageBox.Show("Successfuly Inserted...^_^");
                clear();
                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();

            }
            else 
            {
                MessageBox.Show("Not Inserted...^_^");
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();   
        }
        private void clear() 
        {
            txtId.Text = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtClass.Text = "";
            txtStream.Text = "";
            txtSem.Text = "";
            txtCity.Text = "";
            txtId.Focus();
        }

        private void clas_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

      
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ResultWindowsForms
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void txtId_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            display();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void display() 
        {
            string sel = "select * from student";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            int a = sda.Fill(Class1.dt);
            dataGridView1.DataSource = Class1.dt;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            MessageBox.Show("Do you want to create result...^_^");
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }
    }
}

﻿namespace ResultWindowsForms
{
    partial class Form1
    {
     
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.id = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.txtClass = new System.Windows.Forms.TextBox();
            this.clas = new System.Windows.Forms.Label();
            this.stream = new System.Windows.Forms.Label();
            this.sem = new System.Windows.Forms.Label();
            this.city = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.NumericUpDown();
            this.txtSem = new System.Windows.Forms.NumericUpDown();
            this.txtCity = new System.Windows.Forms.ComboBox();
            this.txtStream = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.txtId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSem)).BeginInit();
            this.SuspendLayout();
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id.Location = new System.Drawing.Point(78, 74);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(53, 28);
            this.id.TabIndex = 0;
            this.id.Text = "I\'d : ";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(142, 125);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(179, 36);
            this.txtName.TabIndex = 2;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(53, 125);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(86, 28);
            this.name.TabIndex = 2;
            this.name.Text = "Name : ";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(142, 165);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(179, 57);
            this.txtAddress.TabIndex = 3;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.Location = new System.Drawing.Point(31, 181);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(106, 28);
            this.address.TabIndex = 4;
            this.address.Text = "Address : ";
            // 
            // txtClass
            // 
            this.txtClass.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClass.Location = new System.Drawing.Point(448, 68);
            this.txtClass.Name = "txtClass";
            this.txtClass.Size = new System.Drawing.Size(179, 36);
            this.txtClass.TabIndex = 4;
            // 
            // clas
            // 
            this.clas.AutoSize = true;
            this.clas.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clas.Location = new System.Drawing.Point(351, 72);
            this.clas.Name = "clas";
            this.clas.Size = new System.Drawing.Size(78, 28);
            this.clas.TabIndex = 6;
            this.clas.Text = "Class : ";
            this.clas.Click += new System.EventHandler(this.clas_Click);
            // 
            // stream
            // 
            this.stream.AutoSize = true;
            this.stream.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stream.Location = new System.Drawing.Point(336, 104);
            this.stream.Name = "stream";
            this.stream.Size = new System.Drawing.Size(96, 28);
            this.stream.TabIndex = 8;
            this.stream.Text = "Stream : ";
            // 
            // sem
            // 
            this.sem.AutoSize = true;
            this.sem.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sem.Location = new System.Drawing.Point(360, 167);
            this.sem.Name = "sem";
            this.sem.Size = new System.Drawing.Size(70, 28);
            this.sem.TabIndex = 10;
            this.sem.Text = "Sem : ";
            // 
            // city
            // 
            this.city.AutoSize = true;
            this.city.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.city.Location = new System.Drawing.Point(366, 203);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(68, 28);
            this.city.TabIndex = 12;
            this.city.Text = "City : ";
            // 
            // txtId
            // 
            this.txtId.Enabled = false;
            this.txtId.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtId.Location = new System.Drawing.Point(142, 72);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(179, 36);
            this.txtId.TabIndex = 1;
            // 
            // txtSem
            // 
            this.txtSem.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSem.Location = new System.Drawing.Point(448, 162);
            this.txtSem.Name = "txtSem";
            this.txtSem.Size = new System.Drawing.Size(179, 36);
            this.txtSem.TabIndex = 6;
            // 
            // txtCity
            // 
            this.txtCity.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.FormattingEnabled = true;
            this.txtCity.Items.AddRange(new object[] {
            "Rajkot",
            "Jetpur",
            "Surat"});
            this.txtCity.Location = new System.Drawing.Point(448, 196);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(179, 36);
            this.txtCity.TabIndex = 7;
            // 
            // txtStream
            // 
            this.txtStream.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStream.FormattingEnabled = true;
            this.txtStream.Items.AddRange(new object[] {
            "B.Sc.It",
            "BCA"});
            this.txtStream.Location = new System.Drawing.Point(448, 97);
            this.txtStream.Name = "txtStream";
            this.txtStream.Size = new System.Drawing.Size(179, 36);
            this.txtStream.TabIndex = 5;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(83, 268);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(114, 35);
            this.btnSubmit.TabIndex = 8;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(462, 268);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(114, 35);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 314);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtStream);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtSem);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.city);
            this.Controls.Add(this.sem);
            this.Controls.Add(this.stream);
            this.Controls.Add(this.txtClass);
            this.Controls.Add(this.clas);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.address);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.name);
            this.Controls.Add(this.id);
            this.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label id;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox txtClass;
        private System.Windows.Forms.Label clas;
        private System.Windows.Forms.Label stream;
        private System.Windows.Forms.Label sem;
        private System.Windows.Forms.Label city;
        private System.Windows.Forms.NumericUpDown txtId;
        private System.Windows.Forms.NumericUpDown txtSem;
        private System.Windows.Forms.ComboBox txtCity;
        private System.Windows.Forms.ComboBox txtStream;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClear;
    }
}


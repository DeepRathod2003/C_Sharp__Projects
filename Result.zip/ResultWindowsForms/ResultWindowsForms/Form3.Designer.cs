﻿namespace ResultWindowsForms
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnResult = new System.Windows.Forms.Button();
            this.txtCsharp = new System.Windows.Forms.NumericUpDown();
            this.txtJava = new System.Windows.Forms.NumericUpDown();
            this.csharp = new System.Windows.Forms.Label();
            this.java = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtNet = new System.Windows.Forms.NumericUpDown();
            this.txtOs = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txtCsharp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJava)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOs)).BeginInit();
            this.SuspendLayout();
            // 
            // btnResult
            // 
            this.btnResult.Location = new System.Drawing.Point(118, 110);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(104, 39);
            this.btnResult.TabIndex = 5;
            this.btnResult.Text = "Result";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // txtCsharp
            // 
            this.txtCsharp.Location = new System.Drawing.Point(118, 54);
            this.txtCsharp.Name = "txtCsharp";
            this.txtCsharp.Size = new System.Drawing.Size(163, 26);
            this.txtCsharp.TabIndex = 2;
            // 
            // txtJava
            // 
            this.txtJava.Location = new System.Drawing.Point(118, 12);
            this.txtJava.Name = "txtJava";
            this.txtJava.Size = new System.Drawing.Size(163, 26);
            this.txtJava.TabIndex = 1;
            // 
            // csharp
            // 
            this.csharp.AutoSize = true;
            this.csharp.Location = new System.Drawing.Point(17, 56);
            this.csharp.Name = "csharp";
            this.csharp.Size = new System.Drawing.Size(41, 20);
            this.csharp.TabIndex = 27;
            this.csharp.Text = "C# :";
            // 
            // java
            // 
            this.java.AutoSize = true;
            this.java.Location = new System.Drawing.Point(17, 18);
            this.java.Name = "java";
            this.java.Size = new System.Drawing.Size(64, 20);
            this.java.TabIndex = 13;
            this.java.Text = "JAVA :";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(383, 110);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(104, 39);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // txtNet
            // 
            this.txtNet.Location = new System.Drawing.Point(383, 60);
            this.txtNet.Name = "txtNet";
            this.txtNet.Size = new System.Drawing.Size(163, 26);
            this.txtNet.TabIndex = 4;
            // 
            // txtOs
            // 
            this.txtOs.Location = new System.Drawing.Point(383, 12);
            this.txtOs.Name = "txtOs";
            this.txtOs.Size = new System.Drawing.Size(163, 26);
            this.txtOs.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(314, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Net. :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(322, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 20);
            this.label2.TabIndex = 28;
            this.label2.Text = "OS :";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 175);
            this.Controls.Add(this.txtNet);
            this.Controls.Add(this.txtOs);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.txtCsharp);
            this.Controls.Add(this.txtJava);
            this.Controls.Add(this.csharp);
            this.Controls.Add(this.java);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtCsharp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJava)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.NumericUpDown txtCsharp;
        private System.Windows.Forms.NumericUpDown txtJava;
        private System.Windows.Forms.Label csharp;
        private System.Windows.Forms.Label java;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.NumericUpDown txtNet;
        private System.Windows.Forms.NumericUpDown txtOs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
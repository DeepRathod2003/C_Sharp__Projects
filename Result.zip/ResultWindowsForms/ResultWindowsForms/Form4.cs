﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace ResultWindowsForms
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void display()
        {
            string sel = "select * from result";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            int a = sda.Fill(Class1.dt);
            dataGridView1.DataSource = Class1.dt;
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            display();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
